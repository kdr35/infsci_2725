
library(ggplot2)
library(sqldf)
library(FSelector)
library(psych)

nobel=na.omit(read.csv("nobel.csv"))
income=na.omit(read.csv("median_income.csv"))

#Nobel vs Chocolate Plot
ggplot(data=nobel, aes(x=choc, y=nobel.per.10.million)) +
  ylab("Nobel Laureates per 10 Million") + xlab("Chocolate in kg per Capita") +
  geom_point(size=4) + geom_text(aes(label=Country), 
  size=5, position=position_jitter(width=.5, height=.5))

#Nobel by Chocolate Correlation and Regression
cor(nobel$nobel.per.10.million, nobel$choc)
lm1=lm(data=nobel,nobel.per.10.million~choc)
summary(lm1)
hist(lm1$residual)
plot(lm1$fitted.values, lm1$residual)

#Join Datasets
join=merge(nobel, income, by="Country")

#Nobel vs Income Plot
ggplot(data=join, aes(x=median.hh.income, y=nobel.per.10.million)) +
  ylab("Nobel Laureates per 10 Million") + xlab("Median Household Income") +
  geom_point(size=4) + geom_text(aes(label=Country), 
                                 size=5, position=position_jitter(width=.5, height=.5))

#Nobel by Income Correlation and Regression
cor(join$nobel.per.10.million, join$median.hh.income)
lm2=lm(data=join,nobel.per.10.million~median.hh.income)
summary(lm2)
hist(lm2$residual)
plot(lm2$fitted.values, lm1$residual)

#Chocolate by Income Correlation (they are slightly collinear)
cor(join$choc, join$median.hh.income)

#Nobel by Chocolate+Income Regression
lm3=lm(data=join,nobel.per.10.million~choc+median.hh.income)
summary(lm3)
hist(lm3$residual)
plot(lm3$fitted.values, lm1$residual)

####################################################################

data1=na.omit(read.csv("nobel_rev2.csv"))

ggplot(data=data1, aes(x=GDP.per.capita, y=nobel.per.10.million)) +
  ylab("Nobel Laureates per 10 Million") + xlab("Gross domestic product per capita") +
  geom_point(size=4) + geom_text(aes(label=Country),
                                 size=5, position=position_jitter(width=.5, height=.5))

cor(data1$nobel.per.10.million, data1$GDP.per.capita)
summary(lm(data=data1,nobel.per.10.million~GDP.per.capita))

ggplot(data=data1, aes(x=elem.sec.edu.expenditures.per.FTE.student, y=nobel.per.10.million)) +
  ylab("Nobel Laureates per 10 Million") + xlab("Elementary and secondary education expenditures per FTE student") +
  geom_point(size=4) + geom_text(aes(label=Country),
                                 size=5, position=position_jitter(width=.5, height=.5))

cor(data1$nobel.per.10.million, data1$elem.sec.edu.expenditures.per.FTE.student)
summary(lm(data=data1,nobel.per.10.million~elem.sec.edu.expenditures.per.FTE.student))

ggplot(data=data1, aes(x=higher.edu.expenditures.per.FTE.student, y=nobel.per.10.million)) +
  ylab("Nobel Laureates per 10 Million") + xlab("Higher education expenditures per FTE student") +
  geom_point(size=4) + geom_text(aes(label=Country),
                                 size=5, position=position_jitter(width=.5, height=.5))

cor(data1$nobel.per.10.million, data1$higher.edu.expenditures.per.FTE.student)
summary(lm(data=data1,nobel.per.10.million~higher.edu.expenditures.per.FTE.student))

ggplot(data=data1, aes(x=expenditure.edu.percent.total.government.expenditure.percent, y=nobel.per.10.million)) +
  ylab("Nobel Laureates per 10 Million") + xlab("Expenditure on education as % of total government expenditure (%)") +
  geom_point(size=4) + geom_text(aes(label=Country),
                                 size=5, position=position_jitter(width=.5, height=.5))

cor(data1$nobel.per.10.million, data1$expenditure.edu.percent.total.government.expenditure.percent)
summary(lm(data=data1,nobel.per.10.million~expenditure.edu.percent.total.government.expenditure.percent))

####################################################################

data1=read.csv("nobel_rev2.csv")

#Join Datasets
master=merge(data1, income, by="Country")

#Make shorter named variables for correlation matrix
short=master[,c(5:11)]
short$nobel=short$nobel.per.10.million
short$edu.gov=short$expenditure.edu.percent.total.government.expenditure.percent
short$gdp=short$GDP.per.capita
short$elem.sec.edu=short$elem.sec.edu.expenditures.per.FTE.student
short$higher.edu=short$higher.edu.expenditures.per.FTE.student
short$income=short$median.hh.income
cor(short[,c(2,8:13)], use="pairwise.complete.obs")

#Which measure of national wealth?
  #median.hh.income seems to be strongest predictor.
summary(lm(data=master,nobel.per.10.million~median.hh.income+GDP.per.capita))

#Which student expenditure variable?
  #elem.sec.edu.expenditures.per.FTE.student seems to be the strongest predictor.
summary(lm(data=master,nobel.per.10.million~elem.sec.edu.expenditures.per.FTE.student
   +higher.edu.expenditures.per.FTE.student
   +expenditure.edu.percent.total.government.expenditure.percent))

#Regress all combinations of choc, median.hh.income, and elem.sec.edu.expenditures.per.FTE.student

mult1=lm(data=master,nobel.per.10.million~choc+median.hh.income)
summary(mult1)

mult2=lm(data=master,nobel.per.10.million~choc+elem.sec.edu.expenditures.per.FTE.student)
summary(mult2)

mult3=lm(data=master,nobel.per.10.million~median.hh.income+elem.sec.edu.expenditures.per.FTE.student)
summary(mult3)

full.model=lm(data=master,nobel.per.10.million~
  choc+median.hh.income+elem.sec.edu.expenditures.per.FTE.student)
summary(full.model)

#PCA doesn't really help
no.miss=na.omit(short)
pca=princomp(no.miss[,c(9:13)])
plot(pca,type="lines")
principal(no.miss[,c(9:13)], nfactors=2, rotate="varimax")

#All possible model selection to maximize adjusted R-squared
regressors=c("choc","edu.gov","gdp","elem.sec.edu","higher.edu","income")
grid=expand.grid(c(TRUE,FALSE),c(TRUE,FALSE),c(TRUE,FALSE),c(TRUE,FALSE),c(TRUE,FALSE),c(TRUE,FALSE))
grid <- grid[-(dim(grid)[1]),]
names(grid)=paste("y",1:6,sep="")
allmodelslist=apply(grid,1,function(x)as.formula(
  paste(c("nobel~1", regressors[x]), collapse="+")))
rlist=lapply(allmodelslist,function(x)summary(lm(data=no.miss,x))$adj.r.squared)
rdf=order(-data.frame(rlist))
rdf
best.model=allmodelslist$'19'
best.model
summary(lm(data=no.miss, nobel ~ choc + gdp + elem.sec.edu + income))

