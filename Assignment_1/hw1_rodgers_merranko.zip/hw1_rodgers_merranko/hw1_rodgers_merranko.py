#import pymongo
import pymongo

#import connection requests library
from pymongo import MongoClient

#Create a new connection 
client = MongoClient()

#Set the database
db = client['moviesdb']

#Set the collection 
movieCollection = db.movies

#Get ratings and tags from files and store each in a list sorted in descending order
ratings = [] 
with open("ratings.dat", "r") as r:
    for line in r:
        rating_list = line.rstrip('\r\n').split("::") #split string from current line in the file
        ratings.append(rating_list) #add rating in ratings list       
ratings.sort(key=lambda elem: int(elem[1]), reverse=True) #sort list by movieID

tags = []
with open("tags.dat", "r") as t:
    for line in t:
        tag_list = line.rstrip('\r\n').split("::") #split string from current line in the file
        tags.append(tag_list) #add tag in tags list
tags.sort(key=lambda elem: int(elem[1]), reverse=True) #sort list by movieID

#Go through the movies file and insert each movie with corresponding tags and ratings in the database
with open("movies.dat", "r") as m:
    for line in m:
        movie_info = line.rstrip('\r\n').split("::") #split string from current line in the file
        #create movie dict and store movie info
        movie = {}
        movie['movieID'] = int(movie_info[0])
        movie['title'] = movie_info[1]
        movie['genres'] = []
        genre_list = movie_info[2].split("|") #split the string associated with the movie genres
        for genre in genre_list:
            movie['genres'].append({"genre_name":genre}) #add each genre to the movie object

        #Iterate through the tags list and add each tag info that corresponds to the movie the file readline is currently on
        #to the movie document. Once the tag has been added, remove it from the list. The tags list is sorted so whenever
        #the tags list movieID is greater than the current movie's movieID exit reading through the tags list
        for t in reversed(tags):
            if(int(t[1]) == movie['movieID']):
                if 'tags' not in movie:
                    movie['tags'] = []
                movie['tags'].append({'userID':int(t[0]), 'tag':t[2], 'timestamp':t[3]})
                tags.pop()
            if(int(t[1]) > movie['movieID']):
                break

        #Iterate through the ratings list and add each rating info that corresponds to the movie the file readline is currently on
        #to the movie document. Once the rating has been added, remove it from the list. The ratings list is sorted so whenever
        #the ratings list movieID is greater than the current movie's movieID exit reading through the ratings list
        for r in reversed(ratings):
            if(int(r[1]) == movie['movieID']):
                if 'ratings' not in movie:
                    movie['ratings'] = []
                movie['ratings'].append({'userID':int(r[0]), 'rating':float(r[2]), 'timestamp':r[3]})
                ratings.pop()
            if(int(r[1]) > movie['movieID']):
                break
       
        movieCollection.insert(movie) #insert movie into database movies collection

###What genre is the movie CopyCat in?
print('What genre is the movie CopyCat in?')
query = db.movies.aggregate([
    {"$match": {"title" : {"$regex": "CopyCat", "$options": "-i"}}},
    {"$unwind": "$genres"},
    {"$group": {"_id" : "$genres.genre_name"}}
])
for document in query:
    print(document['_id'])

###what genre has the most movies?
print('what genre has the most movies?')
query = db.movies.aggregate([
    {"$unwind": "$genres"},
    {"$group": {"_id" : "$genres.genre_name", "count": {"$sum": 1}}},
    {"$sort": {"count":-1}},
    {"$limit": 1}
])
for document in query:
    print(document['_id'])

###what tags did user 146 use to describe the movie "2001: A Space Odyssey?
print('what tags did user 146 use to describe the movie "2001: A Space Odyssey?')
query = db.movies.aggregate([
    {"$match": {"title" : {"$regex": "2001: A Space Odyssey", "$options": "-i"}}},
    {"$unwind": "$tags"},
    {"$match": {"tags.userID" : 146}},
    {"$group": {"_id" : "$tags.tag"}}
])
for document in query:
    print(document['_id'])

###What are the top 5 movies with the highest avg rating?
print('What are the top 5 movies with the highest avg rating?')
query = db.movies.aggregate([
    {"$unwind": "$ratings"},
    {"$group": {"_id" : "$title", "average": {"$avg": "$ratings.rating"}}},
    {"$sort": {"average":-1}},
    {"$limit": 5}
])
for document in query:
    print(document['_id'])

###What is the highest avg rating possible?
print('What is the highest avg rating possible?')
query = db.movies.aggregate([
    {"$unwind": "$ratings"},
    {"$group": {"_id" : "$title", "average": {"$avg": "$ratings.rating"}}},
    {"$sort": {"average":-1}},
    {"$limit": 1}
])
for document in query:
    print(document['average'])

###What are the bottom 5 movies by their average rating?
print('What are the bottom 5 movies by their average rating?')
query = db.movies.aggregate([
    {"$unwind": "$ratings"},
    {"$group": {"_id" : "$title", "average": {"$avg": "$ratings.rating"}}},
    {"$sort": {"average":1}},
    {"$limit": 5}
])
for document in query:
    print(document['_id'] + " with an average rating of " + str(round(document['average'],3)))

###What are the top 5 genres with highest average movie rating?
print('What are the top 5 genres with highest average movie rating?')
query = db.movies.aggregate([
    {"$unwind": "$ratings"},
    {"$unwind": "$genres"},
    {"$group": {"_id" : "$genres.genre_name", "average": {"$avg": "$ratings.rating"}}},
    {"$sort": {"average":-1}},
    {"$limit": 5}
])
for document in query:
    print(document['_id'] + " with an average rating of " + str(round(document['average'],3)))

###What is the average rating from userID 34?
print('What is the highest average rating from userID 34?')
query = db.movies.aggregate([
    {"$unwind": "$ratings"},
    {"$match": {"ratings.userID" : 34}},
    {"$group": {"_id" : "$ratings.userID", "average": {"$avg": "$ratings.rating"}}}
])
for document in query:
    print("Average rating given from userID " + str(document['_id']) + " is " + str(round(document['average'],3)))
    
###get the total counts of movies, tags, and ratings
###count of total number of movies
cursor = db.movies.find().count()
print(cursor)

###count of total number of tags
query = db.movies.aggregate([
    {"$unwind": "$tags"},
    {"$group": {"_id" : "TagsCount", "count": {"$sum": 1}}}
])
for document in query:
    print(document)

###count of total number of ratings
query = db.movies.aggregate([
    {"$unwind": "$ratings"},
    {"$group": {"_id" : "RatingsCount", "count": {"$sum": 1}}},
], allowDiskUse = True)
for document in query:
    print(document)

#close connection
client.close()
