#Read in data
data=read.delim("retention.txt")

#Descriptive stats (min, max, first and second quartiles, mean, and median)
summary(data)

#Summary doesn't compute standard deviations, so this applies the SD function to all variables in data
sapply(data, sd)

#Histograms
hist(data$spend)  #Right Skewed
hist(data$apret)  #Fairly Normal
hist(data$top10)  #Right Skewed
hist(data$rejr)   #Right Skewed
hist(data$tstsc)  #Right Skewed
hist(data$pacc)   #Right Skewed
hist(data$strat)  #Fairly Normal
hist(data$salar)  #Fairly Normal

#Scatterplot matrices 
#(first just the three variables we are supposed to focus on, then all possible)
pairs(data=data,~spend+tstsc+salar)  #Relationships between all three are approximately linear
pairs(data=data,~spend+apret+top10+rejr+tstsc+pacc+strat+salar) #Click zoom to enlarge plots
dev.off() #this clears current graphical device (usually not necessary)

#Linear regressions
lm1=lm(data=data,apret~tstsc)
lm2=lm(data=data,apret~salar)
lm3=lm(data=data,apret~tstsc+salar)
summary(lm1)
summary(lm2)
summary(lm3)

#Plot residuals of regressions
#Not perfectly normal, but they should suffice
hist(lm1$residual)
hist(lm2$residual)
hist(lm3$residual)
#No overtly blatant patterns in plotted residuals~fitted values
plot(lm1$fitted.values, lm1$residual) #Slight funnel shape
plot(lm2$fitted.values, lm2$residual) #Perfect
plot(lm3$fitted.values, lm3$residual) #Again, slight funnel shape
